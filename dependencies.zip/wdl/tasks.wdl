version 1.0

# ================== COPYRIGHT ================================================
# New York Genome Center
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright (2026) by the New York
# Genome Center. All rights are reserved. This software is supplied without
# any warranty or guaranteed support whatsoever. The New York Genome Center
# cannot be responsible for its use, misuse, or functionality.
#
#    Nico Robine (nrobine@nygenome.org)
#    Valentina Grether
#    Zoe R. Goldstein (zgoldstein@nygenome.org)
#    Jennifer M Shelton (jshelton@nygenome.org)
#    Timothy R. Chu (tchu@nygenome.org)
#    William F. Hooper (whooper@nygenome.org)
#    Heather Geiger (hgeigher @nygenome.org)
#    André Corvelo (acorvelo@nygenome.org)
#    Rachel Martini 
#    Melissa B. Davis
# 
#
# ================== /COPYRIGHT ===============================================
# additional tasks for the ALCHEMIST pipeline

import "wdl_structs.wdl"

task FragCounter {
    input {
        Bram bram
        IndexedReference referenceFa
        String sampleId
        String rdsPath="~{sampleId}.cov.rds"
        String rawRdsPath="~{sampleId}.cov.raw.rds"
        String correctedBwPath="~{sampleId}.cov.corrected.bw"
        String oneKbRdsPath="~{sampleId}.1kb_cov.rds"
        Int diskSize
        Int memoryGb
        String normal
        String tumor
        File rawVcf
        String orderedVcfPath
    }

    command <<<
        set -e -o pipefail

        bram="~{bram.bam}"
        referenceFa="~{referenceFa.fasta}"
        sampleId="~{sampleId}"
        rdsPath="~{sampleId}.cov.rds"
        rawRdsPath="~{sampleId}.cov.raw.rds"
        correctedBwPath="~{sampleId}.cov.corrected.bw"
        oneKbRdsPath="~{sampleId}.1kb_cov.rds"

        frag \
        --bam ${bram} \
        --window 1000 \
        --gcmapdir /usr/local/lib/R/site-library/fragCounter/extdata/gcmap.38 \
        --paired TRUE \
        --reference ${referenceFa} \
        --outdir . \
        --libdir /usr/local/lib/R/site-library/fragCounter/extdata/

        mv \
        cov.rds ${rdsPath}
        mv \
        cov.raw.rds ${rawRdsPath}
        mv \
        cov.corrected.bw ${correctedBwPath} 
        mv \
        1kb_cov.rds ${oneKbRdsPath}
    >>>

    output {
        File rds= "~{rdsPath}"
        File rawRds= "~{rawRdsPath}"
        File correctedBw= "~{correctedBwPath}"
        File oneKbRds= "~{oneKbRdsPath}"
    }

    runtime {
        mem: memoryGb + "G"
        disks: "local-disk " + diskSize + " HDD"
        memory : memoryGb + "GB"
        docker : "us.gcr.io/nygc-comp-s-fd4e/fragcounter@sha256:1f04990656cb7a6aecb763c0684caf5d885f66c7fc5f720014f3e68baf60806b"
        runtime_minutes: "90"
    }
}


task CountHetsSnps {
    input {
        File countHetsScript
        File hetSnpsScript
        File gnomADMaf
        Bram tumorBram
        Bram normalBram
        Int diskSize
        Int memoryGb
        String pairId
        String hetSnpsCountsTsvPath = "~{pairId}.het_snps_counts.tsv"
    }

    command <<<
        set -e -o pipefail

        hetSnpsScript=~{hetSnpsScript}
        gnomADMaf=~{gnomADMaf}
        tumorBram=~{tumorBram.bam}
        normalBram=~{normalBram.bam}
        hetSnpsCountsTsvPath=~{hetSnpsCountsTsvPath}

        python \
        ${hetSnpsScript} \
        --het-sites ${gnomADMaf} \
        --tumor-bam ${tumorBram} \
        --normal-bam ${normalBram} \
        --out ${hetSnpsCountsTsvPath}
    >>>

    output {
        File hetSnpsCountsTsv = "~{hetSnpsCountsTsvPath}"
    }

    runtime {
        mem: memoryGb + "G"
        disks: "local-disk " + diskSize + " HDD"
        memory : memoryGb + "GB"
        docker : "gcr.io/nygc-public/somatic_dna_tools@sha256:f281e73ddf515f3a5db6e766ef12fb2331dafa2b27c88e426764dcd8b4a7e19b"
        runtime_minutes: "90"
    }
}



us.gcr.io/nygc-comp-s-fd4e/hapaseg_local@sha256:29345c386af52082caf0621be73fbbac4b70a88435b8c64f8262b84d7716cd5f

task HapaSegLocal {
    input {
        Bram tumorBram
        Bram normalBram
        String pairId
        File hetSnpsCountsTsv
        Int diskSize
        Int memoryGb = 16
        Int threads = 8
    }

    command <<<
        set -e -o pipefail

        hetSnpsCountsTsv=~{hetSnpsCountsTsv}
        tumorBram=~{tumorBram.bam}
        normalBram=~{normalBram.bam}

        hapaseg_local \
        --is-ffpe ... \
        --ref-root-path ... \
        --ref-genome-build hg38 \
        --tumor-bam ${tumorBram} \
        --tumor-bai ~{tumorBram.bai} \
        --normal-bam ${normalBram} \
        --normal-bai ~{normalBram.bai} \
        --het-site-calls ${hetSnpsCountsTsv}
    >>>

    output {
        File hetSnpsCountsTsv = "~{hetSnpsCountsTsvPath}"
    }

    runtime {
        mem: memoryGb + "G"
        disks: "local-disk " + diskSize + " HDD"
        memory : memoryGb + "GB"
        docker : "gcr.io/nygc-public/somatic_dna_tools@sha256:f281e73ddf515f3a5db6e766ef12fb2331dafa2b27c88e426764dcd8b4a7e19b"
        runtime_minutes: "90"
    }
}