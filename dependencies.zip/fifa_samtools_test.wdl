version 1.0

# ================== COPYRIGHT ================================================
# New York Genome Center
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright (2026) by the New York
# Genome Center. All rights are reserved. This software is supplied without
# any warranty or guaranteed support whatsoever. The New York Genome Center
# cannot be responsible for its use, misuse, or functionality.
#
#    Nico Robine (nrobine@nygenome.org)
#    Valentina Grether
#    Zoe R. Goldstein (zgoldstein@nygenome.org)
#    Jennifer M Shelton (jshelton@nygenome.org)
#    Timothy R. Chu (tchu@nygenome.org)
#    William F. Hooper (whooper@nygenome.org)
#    Heather Geiger (hgeigher @nygenome.org)
#    André Corvelo (acorvelo@nygenome.org)
#    Rachel Martini 
#    Melissa B. Davis
# 
#
# ================== /COPYRIGHT ===============================================

# Workflow from https://www.biorxiv.org/content/10.64898/2026.03.10.710815v1
# An explainable boosting machine model for identifying artifacts caused by formalin-fixed paraffin embedding
import "wdl/wdl_structs.wdl"
import "wdl/prediction_wkf.wdl" as predictionWkf
import "wdl/fifa.wdl" as fifaTasks

workflow PredictionBucketedWkf {
    input {
        Boolean local = true
        String bamFilenamePath = "5139a13a-98a1-472c-8fe8-21a224af3817_wgs_gdc_realn.bam"
        File bamFile = "gs://nygc-comp-p-06c2-workspace/PredictionBucketedWkf/81b28f01-298b-453b-862b-441a385adf3d/call-bamDownload/cacheCopy/5139a13a-98a1-472c-8fe8-21a224af3817_wgs_gdc_realn.bam"
        # resources
        String qos = "compbio"
        String partition = "cpu"
        String cpuPlatform = "Intel Cascade Lake"
    }
    if (!local) {
        Int cloudMaxSplits = 5
        Int cloudMinSplits = 2
    }
    if (local) {
        Int hpcMaxSplits = 4
        Int hpcMinSplits = 2
    }

    call fifaTasks.TestBucketRead {
            input:
                finalBam = bamFile
        }
    output {
        File success = TestBucketRead.header
    }

}