version 1.0

# ================== COPYRIGHT ================================================
# New York Genome Center
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright (2026) by the New York
# Genome Center. All rights are reserved. This software is supplied without
# any warranty or guaranteed support whatsoever. The New York Genome Center
# cannot be responsible for its use, misuse, or functionality.
#
#    Nico Robine (nrobine@nygenome.org)
#    Valentina Grether
#    Zoe R. Goldstein (zgoldstein@nygenome.org)
#    Jennifer M Shelton (jshelton@nygenome.org)
#    Timothy R. Chu (tchu@nygenome.org)
#    William F. Hooper (whooper@nygenome.org)
#    Heather Geiger (hgeigher @nygenome.org)
#    André Corvelo (acorvelo@nygenome.org)
#    Rachel Martini 
#    Melissa B. Davis
# 
#
# ================== /COPYRIGHT ===============================================

# Workflow from https://www.biorxiv.org/content/10.64898/2026.03.10.710815v1
# An explainable boosting machine model for identifying artifacts caused by formalin-fixed paraffin embedding
import "wdl/wdl_structs.wdl"


task MakeVariantBucketed {
    input {
        Bram finalBram
        File features1000Bed = "gs://nygc-comp-p-06c2-input/somatic/gnomAD_MAF10_50pct_45prob_hg38_final27.tsv"
        String sampleId = "ALCH-ABMM-NB1-A-1-0-D-A488-36"
        String variantCramPath = "~{sampleId}.variantRegions.bam"
        String variantCraiPath = "~{sampleId}.variantRegions.bai"
        IndexedReference referenceFa
        Int slopSizeBp = 1000
        # resources
        String? gcpProject 
        File? serviceAccountKey
        Int diskSize
        Int threads = 4
        Int runRequestThreads =  ceil(threads / 2.0)
        Int memoryGb = 16
    }
    command <<<
        set -e -o pipefail
        serviceAccountKey=~{serviceAccountKey}
        if [ -f "$serviceAccountKey" ]; then
            export GCS_REQUESTER_PAYS_PROJECT=~{gcpProject}
            export GOOGLE_APPLICATION_CREDENTIALS=~{serviceAccountKey}
            export GOOGLE_CLOUD_PROJECT=~{gcpProject}
            # expires in 60 min
            export GCS_OAUTH_TOKEN=`gcloud auth application-default print-access-token`
        fi

        cat ~{features1000Bed} \
        | grep -v "^@"  \
        | head -n 10000 \
        > features1000Bed_subset.bed

        time \
        samtools view \
        --threads ~{threads} \
        -h \
        --bam \
        --reference ~{referenceFa.fasta} \
        -L features1000Bed_subset.bed \
        -X ~{finalBram.bram} \
        ~{finalBram.bramIndex} \
        > ~{variantCramPath}

        samtools \
        index \
        -@ ~{threads} \
        ~{variantCramPath} \
        ~{variantCraiPath}
    >>>

    output {
        Cram variantCram = object {
                cram : "~{variantCramPath}",
                cramIndex : "~{variantCraiPath}"
             }
    }
    runtime {
        docker:  "us.gcr.io/nygc-comp-s-fd4e/samtoolsgcs@sha256:e44efa1effd03df21f14ce1d7ca586276bee053d64e3420897ae9d4fdf11d1a9"
        disks: "local-disk " + diskSize + " HDD"
        memory: memoryGb + "GB"
        mem: memoryGb + "G"
        cpu : threads
        cpus: runRequestThreads
        runtime_minutes: "600"
        maxRetries : 2
    }
    parameter_meta {
        finalBram: {
            description: "Input BRAM filename",
            category: "required",
            localization_optional: true
        }
    }
}

task MakeVariantLocal {
    input {
        Bram finalBram 
        File features1000Bed = "gs://nygc-comp-p-06c2-input/somatic/gnomAD_MAF10_50pct_45prob_hg38_final27.tsv"
        String sampleId = "ALCH-ABMM-NB1-A-1-0-D-A488-36"
        String variantCramPath = "~{sampleId}.variantRegions.bam"
        String variantCraiPath = "~{sampleId}.variantRegions.bai"
        IndexedReference referenceFa
        Int slopSizeBp = 1000
        # resources
        String? gcpProject 
        File? serviceAccountKey
        Int diskSize 
        Int threads = 4
        Int runRequestThreads =  ceil(threads / 2.0)
        Int memoryGb = 16
    }
    command <<<
        set -e -o pipefail
        serviceAccountKey=~{serviceAccountKey}
        if [ -f "$serviceAccountKey" ]; then
            export GCS_REQUESTER_PAYS_PROJECT=~{gcpProject}
            export GOOGLE_APPLICATION_CREDENTIALS=~{serviceAccountKey}
            export GOOGLE_CLOUD_PROJECT=~{gcpProject}
            # expires in 60 min
            export GCS_OAUTH_TOKEN=`gcloud auth application-default print-access-token`
        fi

        cat ~{features1000Bed} \
        | grep -v "^@"  \
        | head -n 10000 \
        > features1000Bed_subset.bed

        time \
        samtools view \
        --threads ~{threads} \
        -h \
        --bam \
        --reference ~{referenceFa.fasta} \
        -L features1000Bed_subset.bed \
        -X ~{finalBram.bram} \
        ~{finalBram.bramIndex} \
        > ~{variantCramPath}

        samtools \
        index \
        -@ ~{threads} \
        ~{variantCramPath} \
        ~{variantCraiPath}
    >>>

    output {
        Cram variantCram = object {
                cram : "~{variantCramPath}",
                cramIndex : "~{variantCraiPath}"
             }
    }
    runtime {
        docker:  "us.gcr.io/nygc-comp-s-fd4e/samtoolsgcs@sha256:e44efa1effd03df21f14ce1d7ca586276bee053d64e3420897ae9d4fdf11d1a9"
        disks: "local-disk " + diskSize + " HDD"
        memory: memoryGb + "GB"
        mem: memoryGb + "G"
        cpu : threads
        cpus: runRequestThreads
        runtime_minutes: "600"
        maxRetries : 2
    }
    parameter_meta {
        finalBram: {
            description: "Input BRAM filename",
            category: "required",
            localization_optional: false
        }
    }
}

workflow PredictionBucketedWkf {
    input {
        IndexedReference referenceFa
        # resources
        String? gcpProject 
        File? serviceAccountKey
        Bram finalBram

    }

    call  MakeVariantBucketed {
            input:
                finalBram = finalBram,
                gcpProject = gcpProject,
                serviceAccountKey = serviceAccountKey,
                referenceFa = referenceFa,
                diskSize = 30
        }

    call MakeVariantLocal {
            input:
                finalBram = finalBram,
                gcpProject = gcpProject,
                serviceAccountKey = serviceAccountKey,
                referenceFa = referenceFa,
                diskSize = 70
        }
    output {
        Cram variantBucketed = MakeVariantBucketed.variantCram
        Cram variantLocal = MakeVariantLocal.variantCram
    }
}

